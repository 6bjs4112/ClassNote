<template lang="">
    <h2>글쓰기</h2>
    <div>
        <form @submit="dataSave">
            <input type="text" name="username" v-model="username"/>
            <input type="text" name="subject" v-model="subject"/>
            <textarea name="contents" v-model="contents"></textarea>
            <input type="submit" value="저장"/>
        </form>
        {{contents}}
    </div>
</template>
<script>
export default {
    data(){
        return{
            username:'',
            subject:'',
            contents:''
        }
    },
    methods:{
        dataSave(e){
            e.preventDefault();
            this.$emit('parent',{
                mode:'list',
                value:{
                    id:Date.now(),
                    name:this.username,
                    subject:this.subject,
                    contents:this.contents
                }
            })
            
        }
    }
}
</script>
<style lang="">
    
</style>
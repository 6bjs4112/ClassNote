import { createStore } from 'vuex'



export default createStore({
  state: {
    mode:'list',
    newsData : [{id:1, name:'홍길동', subject:'제목...', contents:'뉴스내용들...'}]
  },
  getters: {
  },
  mutations: {
    modeEdit(state,str){
      state.mode = str;
    },
    insertNews(state,newValue){
      state.newsData.push(newValue);
    },
    deleteNews(state,delId){
      let d = state.newsData;
      state.newsData = d.filter(obj=>obj.id != delId);
    }
  },
  actions: {
  },
  modules: {
  }
})

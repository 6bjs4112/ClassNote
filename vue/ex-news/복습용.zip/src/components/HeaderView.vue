<template lang="">
    <nav>
        <router-link to="/">Home</router-link> |
        <router-link to="/about">About</router-link> | 
        <router-link to="/news">News</router-link>
        
    </nav>
</template>
<script>
export default {
    
}
</script>
<style lang="">
    
</style>